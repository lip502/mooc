function showloginbox(){
	$(".hide-center").fadeIn("slow");
    $(".overCurtain").fadeIn("slow");
}
function hideloginbox(){
	 $(".hide-center").fadeOut("slow");
	    $(".overCurtain").fadeOut("slow");
}